import { useState } from 'react';
import { UserType } from './types';
import { InvestorDashboard } from './components/InvestorDashboard';
import { EntrepreneurDashboard } from './components/EntrepreneurDashboard';
import { PolicyMakerDashboard } from './components/PolicyMakerDashboard';
import { TrendingUp, Users, Building2, BarChart3 } from 'lucide-react';

function App() {
  const [userType, setUserType] = useState<UserType | null>(null);

  if (!userType) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center mb-4">
              <div className="bg-blue-600 rounded-full p-4">
                <TrendingUp className="w-12 h-12 text-white" />
              </div>
            </div>
            <h1 className="text-5xl font-bold text-gray-900 mb-4">
              Prosperity Prognosticator
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Machine Learning-Powered Startup Success Prediction Platform
            </p>
            <p className="text-gray-500 mt-2">
              Empowering data-driven decisions for investors, entrepreneurs, and policy makers
            </p>
          </div>

          <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
            <button
              onClick={() => setUserType('investor')}
              className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all hover:-translate-y-1 border-2 border-transparent hover:border-blue-500 group"
            >
              <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mb-6 mx-auto group-hover:bg-blue-100 transition-colors">
                <BarChart3 className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Investors</h2>
              <p className="text-gray-600 mb-6">
                Evaluate startup opportunities, optimize portfolio management, and maximize investment returns through predictive analytics.
              </p>
              <ul className="text-left space-y-2 text-sm text-gray-700 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">✓</span>
                  <span>Investment opportunity assessment</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">✓</span>
                  <span>Portfolio risk analysis</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 mt-0.5">✓</span>
                  <span>Success probability forecasting</span>
                </li>
              </ul>
              <div className="text-blue-600 font-semibold group-hover:underline">
                Access Dashboard →
              </div>
            </button>

            <button
              onClick={() => setUserType('entrepreneur')}
              className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all hover:-translate-y-1 border-2 border-transparent hover:border-green-500 group"
            >
              <div className="bg-green-50 rounded-full w-16 h-16 flex items-center justify-center mb-6 mx-auto group-hover:bg-green-100 transition-colors">
                <Users className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Entrepreneurs</h2>
              <p className="text-gray-600 mb-6">
                Gain actionable insights for business planning, identify success factors, and enhance startup viability through data-driven strategies.
              </p>
              <ul className="text-left space-y-2 text-sm text-gray-700 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <span>Success factor identification</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <span>Risk mitigation strategies</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 mt-0.5">✓</span>
                  <span>Actionable recommendations</span>
                </li>
              </ul>
              <div className="text-green-600 font-semibold group-hover:underline">
                Access Dashboard →
              </div>
            </button>

            <button
              onClick={() => setUserType('policymaker')}
              className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all hover:-translate-y-1 border-2 border-transparent hover:border-orange-500 group"
            >
              <div className="bg-orange-50 rounded-full w-16 h-16 flex items-center justify-center mb-6 mx-auto group-hover:bg-orange-100 transition-colors">
                <Building2 className="w-8 h-8 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Policy Makers</h2>
              <p className="text-gray-600 mb-6">
                Inform entrepreneurship policies, design support programs, and stimulate economic development through ecosystem analytics.
              </p>
              <ul className="text-left space-y-2 text-sm text-gray-700 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-orange-600 mt-0.5">✓</span>
                  <span>Ecosystem trend analysis</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-orange-600 mt-0.5">✓</span>
                  <span>Policy impact assessment</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-orange-600 mt-0.5">✓</span>
                  <span>Resource allocation guidance</span>
                </li>
              </ul>
              <div className="text-orange-600 font-semibold group-hover:underline">
                Access Dashboard →
              </div>
            </button>
          </div>

          <div className="mt-16 max-w-4xl mx-auto bg-white rounded-2xl shadow-xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">
              How It Works
            </h3>
            <div className="grid md:grid-cols-4 gap-6 mt-8">
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-bold">1</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Input Data</h4>
                <p className="text-sm text-gray-600">Enter startup information and metrics</p>
              </div>
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-bold">2</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">ML Analysis</h4>
                <p className="text-sm text-gray-600">AI processes multiple success factors</p>
              </div>
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-bold">3</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Prediction</h4>
                <p className="text-sm text-gray-600">Receive success probability score</p>
              </div>
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-bold">4</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Insights</h4>
                <p className="text-sm text-gray-600">Get actionable recommendations</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-md border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setUserType(null)}
              className="flex items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <div className="bg-blue-600 rounded-full p-2">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">Prosperity Prognosticator</span>
            </button>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">
                {userType === 'investor' && 'Investor Dashboard'}
                {userType === 'entrepreneur' && 'Entrepreneur Dashboard'}
                {userType === 'policymaker' && 'Policy Maker Dashboard'}
              </span>
              <button
                onClick={() => setUserType(null)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Change Role
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-8">
        {userType === 'investor' && <InvestorDashboard />}
        {userType === 'entrepreneur' && <EntrepreneurDashboard />}
        {userType === 'policymaker' && <PolicyMakerDashboard />}
      </main>

      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-sm text-gray-600">
            Machine Learning for Startup Success Prediction | Powered by Advanced Analytics
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
