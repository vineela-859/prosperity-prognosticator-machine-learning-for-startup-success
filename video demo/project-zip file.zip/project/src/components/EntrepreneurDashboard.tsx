import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { Startup, Prediction } from '../types';
import { PredictionEngine } from '../lib/predictionEngine';
import { StartupForm } from './StartupForm';
import { PredictionResult } from './PredictionResult';
import { Lightbulb, AlertCircle, TrendingUp, ArrowLeft } from 'lucide-react';

export function EntrepreneurDashboard() {
  const [selectedStartup, setSelectedStartup] = useState<Startup | null>(null);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [showForm, setShowForm] = useState(true);

  const handleSubmit = async (startupData: Partial<Startup>) => {
    try {
      const { data, error } = await supabase
        .from('startups')
        .insert([startupData])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        setSelectedStartup(data);
        const predictionData = PredictionEngine.predict(data);

        const { data: predData, error: predError } = await supabase
          .from('predictions')
          .insert([predictionData])
          .select()
          .single();

        if (predError) {
          console.error('Error saving prediction:', predError);
        } else if (predData) {
          setPrediction(predData);
          setShowForm(false);
        }
      }
    } catch (error) {
      console.error('Error creating startup:', error);
    }
  };

  const getActionableInsights = (pred: Prediction) => {
    const insights = [];

    if (pred.factors_analysis.funding < 60) {
      insights.push({
        category: 'Funding',
        priority: 'high',
        insight: 'Consider raising additional capital to extend your runway and accelerate growth.',
        actions: ['Prepare investor pitch deck', 'Network with VCs and angel investors', 'Explore alternative funding sources']
      });
    }

    if (pred.factors_analysis.team < 60) {
      insights.push({
        category: 'Team',
        priority: 'high',
        insight: 'Expanding your team with key hires could significantly improve success probability.',
        actions: ['Identify critical roles needed', 'Develop recruitment strategy', 'Consider advisory board additions']
      });
    }

    if (pred.factors_analysis.revenue < 60) {
      insights.push({
        category: 'Revenue',
        priority: 'high',
        insight: 'Focus on revenue generation and customer acquisition to demonstrate market validation.',
        actions: ['Develop sales pipeline', 'Implement growth marketing', 'Optimize pricing strategy']
      });
    }

    if (pred.factors_analysis.growth < 60) {
      insights.push({
        category: 'Growth',
        priority: 'medium',
        insight: 'Accelerate growth rate through product improvements and market expansion.',
        actions: ['Analyze growth bottlenecks', 'Explore new market segments', 'Enhance product features']
      });
    }

    if (pred.factors_analysis.traction < 60) {
      insights.push({
        category: 'Market Traction',
        priority: 'high',
        insight: 'Building stronger market traction will improve investor confidence and success potential.',
        actions: ['Focus on customer retention', 'Build case studies and testimonials', 'Expand user base']
      });
    }

    return insights;
  };

  if (showForm) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Business Planning Assistant</h1>
          <p className="text-gray-600">
            Get data-driven insights to improve your startup's success potential
          </p>
        </div>
        <StartupForm onSubmit={handleSubmit} onCancel={() => {}} />
      </div>
    );
  }

  if (selectedStartup && prediction) {
    const insights = getActionableInsights(prediction);

    return (
      <div className="max-w-6xl mx-auto">
        <button
          onClick={() => {
            setSelectedStartup(null);
            setPrediction(null);
            setShowForm(true);
          }}
          className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
          Analyze Another Startup
        </button>

        <PredictionResult prediction={prediction} startup={selectedStartup} />

        <div className="mt-6 bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
            <Lightbulb className="w-6 h-6 text-yellow-500" />
            Actionable Insights & Recommendations
          </h2>

          {insights.length > 0 ? (
            <div className="space-y-6">
              {insights.map((insight, idx) => (
                <div
                  key={idx}
                  className="border-l-4 border-blue-500 bg-blue-50 p-6 rounded-r-lg"
                >
                  <div className="flex items-start gap-3 mb-3">
                    <AlertCircle className={`w-5 h-5 mt-0.5 ${
                      insight.priority === 'high' ? 'text-red-600' : 'text-yellow-600'
                    }`} />
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-gray-900">{insight.category}</h3>
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                          insight.priority === 'high'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {insight.priority.toUpperCase()} PRIORITY
                        </span>
                      </div>
                      <p className="text-gray-700 mb-3">{insight.insight}</p>
                      <div className="bg-white rounded-lg p-4">
                        <p className="text-sm font-medium text-gray-700 mb-2">Recommended Actions:</p>
                        <ul className="space-y-1">
                          {insight.actions.map((action, actionIdx) => (
                            <li key={actionIdx} className="text-sm text-gray-600 flex items-start gap-2">
                              <TrendingUp className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                              <span>{action}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <p className="text-green-800 font-medium">
                  Your startup shows strong fundamentals across all key metrics. Continue executing on your current strategy!
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="mt-6 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg shadow-lg p-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Key Success Factors</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-2">Focus Areas</h4>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• Build and maintain strong unit economics</li>
                <li>• Develop a clear path to profitability</li>
                <li>• Create defensible competitive advantages</li>
                <li>• Focus on customer retention and LTV</li>
              </ul>
            </div>
            <div className="bg-white rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-2">Risk Mitigation</h4>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>• Maintain adequate financial runway</li>
                <li>• Diversify revenue streams</li>
                <li>• Build strong team culture and retention</li>
                <li>• Stay agile and adapt to market feedback</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
