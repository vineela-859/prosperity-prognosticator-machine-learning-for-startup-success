import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Startup } from '../types';
import { PredictionEngine } from '../lib/predictionEngine';
import { BarChart3, TrendingUp, Building2, MapPin, Briefcase } from 'lucide-react';

export function PolicyMakerDashboard() {
  const [startups, setStartups] = useState<Startup[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStartups();
  }, []);

  const fetchStartups = async () => {
    try {
      const { data, error } = await supabase
        .from('startups')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setStartups(data || []);
    } catch (error) {
      console.error('Error fetching startups:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateEcosystemMetrics = () => {
    const industryDistribution = startups.reduce((acc, startup) => {
      acc[startup.industry] = (acc[startup.industry] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const locationDistribution = startups.reduce((acc, startup) => {
      const location = startup.location || 'Unknown';
      acc[location] = (acc[location] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const successDistribution = startups.reduce(
      (acc, startup) => {
        const prediction = PredictionEngine.predict(startup);
        if (prediction.success_probability >= 70) acc.high++;
        else if (prediction.success_probability >= 45) acc.medium++;
        else acc.low++;
        return acc;
      },
      { high: 0, medium: 0, low: 0 }
    );

    const totalFunding = startups.reduce((sum, s) => sum + s.funding_amount, 0);
    const totalRevenue = startups.reduce((sum, s) => sum + s.revenue, 0);
    const avgTeamSize = startups.reduce((sum, s) => sum + s.team_size, 0) / (startups.length || 1);
    const totalJobs = startups.reduce((sum, s) => sum + s.team_size, 0);

    const fundingByYear = startups.reduce((acc, startup) => {
      const year = startup.founding_year;
      if (!acc[year]) acc[year] = { count: 0, funding: 0 };
      acc[year].count++;
      acc[year].funding += startup.funding_amount;
      return acc;
    }, {} as Record<number, { count: number; funding: number }>);

    return {
      industryDistribution,
      locationDistribution,
      successDistribution,
      totalFunding,
      totalRevenue,
      avgTeamSize,
      totalJobs,
      fundingByYear,
    };
  };

  const metrics = calculateEcosystemMetrics();

  const topIndustries = Object.entries(metrics.industryDistribution)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  const topLocations = Object.entries(metrics.locationDistribution)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  const recentYears = Object.entries(metrics.fundingByYear)
    .sort(([a], [b]) => parseInt(b) - parseInt(a))
    .slice(0, 5);

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-gray-300 border-t-blue-600"></div>
        <p className="mt-4 text-gray-600">Loading ecosystem data...</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Startup Ecosystem Analytics</h1>
        <p className="text-gray-600">
          Comprehensive insights for policy development and entrepreneurship support
        </p>
      </div>

      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Total Startups</h3>
            <Building2 className="w-5 h-5 text-blue-600" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{startups.length}</p>
          <p className="text-xs text-gray-500 mt-1">In ecosystem</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Total Funding</h3>
            <TrendingUp className="w-5 h-5 text-green-600" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            ${(metrics.totalFunding / 1000000).toFixed(1)}M
          </p>
          <p className="text-xs text-gray-500 mt-1">Capital invested</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Jobs Created</h3>
            <Briefcase className="w-5 h-5 text-orange-600" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{metrics.totalJobs}</p>
          <p className="text-xs text-gray-500 mt-1">Total employment</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Economic Impact</h3>
            <BarChart3 className="w-5 h-5 text-red-600" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            ${(metrics.totalRevenue / 1000000).toFixed(1)}M
          </p>
          <p className="text-xs text-gray-500 mt-1">Annual revenue</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-blue-600" />
            Success Probability Distribution
          </h2>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">High Success Potential</span>
                <span className="text-sm font-semibold text-green-600">
                  {metrics.successDistribution.high} startups
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-green-500 h-3 rounded-full"
                  style={{
                    width: `${(metrics.successDistribution.high / startups.length) * 100}%`,
                  }}
                />
              </div>
              <p className="text-xs text-gray-600 mt-1">70%+ success probability</p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Medium Success Potential</span>
                <span className="text-sm font-semibold text-yellow-600">
                  {metrics.successDistribution.medium} startups
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-yellow-500 h-3 rounded-full"
                  style={{
                    width: `${(metrics.successDistribution.medium / startups.length) * 100}%`,
                  }}
                />
              </div>
              <p className="text-xs text-gray-600 mt-1">45-70% success probability</p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Needs Support</span>
                <span className="text-sm font-semibold text-red-600">
                  {metrics.successDistribution.low} startups
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-red-500 h-3 rounded-full"
                  style={{
                    width: `${(metrics.successDistribution.low / startups.length) * 100}%`,
                  }}
                />
              </div>
              <p className="text-xs text-gray-600 mt-1">Below 45% success probability</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <Building2 className="w-6 h-6 text-blue-600" />
            Top Industries
          </h2>
          <div className="space-y-4">
            {topIndustries.map(([industry, count]) => (
              <div key={industry}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">{industry}</span>
                  <span className="text-sm font-semibold text-blue-600">{count} startups</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${(count / startups.length) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <MapPin className="w-6 h-6 text-blue-600" />
            Geographic Distribution
          </h2>
          <div className="space-y-3">
            {topLocations.map(([location, count]) => (
              <div key={location} className="flex items-center justify-between">
                <span className="text-sm text-gray-700">{location}</span>
                <span className="text-sm font-semibold text-gray-900">{count} startups</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            Funding Trends by Year
          </h2>
          <div className="space-y-3">
            {recentYears.map(([year, data]) => (
              <div key={year}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">{year}</span>
                  <span className="text-sm text-gray-600">
                    {data.count} startups • ${(data.funding / 1000000).toFixed(1)}M
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Policy Recommendations</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-3">Support Programs</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>
                  Develop targeted incubation programs for industries with high growth potential
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Create mentorship networks connecting experienced entrepreneurs with new founders</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Establish funding matching programs for early-stage ventures</span>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-3">Infrastructure Development</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Invest in co-working spaces and innovation hubs in underserved areas</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Facilitate access to technical resources and research facilities</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Streamline regulatory processes for startup registration and compliance</span>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-3">Access to Capital</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Launch government-backed seed funding initiatives</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Create tax incentives for angel investors and venture capital</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Support alternative financing mechanisms like revenue-based financing</span>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-3">Talent Development</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Integrate entrepreneurship education into academic curricula</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Support upskilling programs in high-demand technical areas</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Foster international talent attraction and retention programs</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
