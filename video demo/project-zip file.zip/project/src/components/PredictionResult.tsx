import { Prediction, Startup } from '../types';
import { AlertTriangle, CheckCircle, TrendingUp, Award } from 'lucide-react';

interface PredictionResultProps {
  prediction: Prediction;
  startup: Startup;
}

export function PredictionResult({ prediction, startup }: PredictionResultProps) {
  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-green-600';
    if (score >= 45) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBg = (score: number) => {
    if (score >= 70) return 'bg-green-50 border-green-200';
    if (score >= 45) return 'bg-yellow-50 border-yellow-200';
    return 'bg-red-50 border-red-200';
  };

  const getRiskColor = (risk: string) => {
    if (risk === 'low') return 'bg-green-100 text-green-800';
    if (risk === 'medium') return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-1">{startup.name}</h2>
            <p className="text-gray-600">{startup.industry}</p>
          </div>
          <span className={`px-4 py-2 rounded-full text-sm font-medium ${getRiskColor(prediction.risk_level)}`}>
            {prediction.risk_level.toUpperCase()} RISK
          </span>
        </div>

        <div className={`rounded-lg border-2 p-8 mb-6 text-center ${getScoreBg(prediction.success_probability)}`}>
          <div className="flex items-center justify-center mb-2">
            <Award className={`w-8 h-8 ${getScoreColor(prediction.success_probability)}`} />
          </div>
          <div className={`text-6xl font-bold mb-2 ${getScoreColor(prediction.success_probability)}`}>
            {prediction.success_probability.toFixed(1)}%
          </div>
          <div className="text-lg text-gray-700 font-medium">Success Probability</div>
          <div className="text-sm text-gray-600 mt-2">
            Confidence Score: {prediction.confidence_score.toFixed(1)}%
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
          <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            Recommendation
          </h3>
          <p className="text-gray-700">{prediction.recommendation}</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Key Strengths
            </h3>
            {prediction.key_strengths.length > 0 ? (
              <ul className="space-y-2">
                {prediction.key_strengths.map((strength, idx) => (
                  <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                    <span className="text-green-600 mt-0.5">•</span>
                    <span>{strength}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-600">No significant strengths identified</p>
            )}
          </div>

          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              Key Risks
            </h3>
            {prediction.key_risks.length > 0 ? (
              <ul className="space-y-2">
                {prediction.key_risks.map((risk, idx) => (
                  <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                    <span className="text-red-600 mt-0.5">•</span>
                    <span>{risk}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-600">No significant risks identified</p>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-8">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Factor Analysis</h3>
        <div className="space-y-4">
          {Object.entries(prediction.factors_analysis).map(([factor, score]) => (
            <div key={factor}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700 capitalize">{factor}</span>
                <span className={`text-sm font-semibold ${getScoreColor(score)}`}>
                  {score.toFixed(0)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all ${
                    score >= 70 ? 'bg-green-500' : score >= 45 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${score}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
