import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Startup, Prediction } from '../types';
import { PredictionEngine } from '../lib/predictionEngine';
import { StartupCard } from './StartupCard';
import { StartupForm } from './StartupForm';
import { PredictionResult } from './PredictionResult';
import { TrendingUp, DollarSign, Target, Plus, ArrowLeft } from 'lucide-react';

export function InvestorDashboard() {
  const [startups, setStartups] = useState<Startup[]>([]);
  const [selectedStartup, setSelectedStartup] = useState<Startup | null>(null);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStartups();
  }, []);

  const fetchStartups = async () => {
    try {
      const { data, error } = await supabase
        .from('startups')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setStartups(data || []);
    } catch (error) {
      console.error('Error fetching startups:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyzeStartup = async (startup: Startup) => {
    setSelectedStartup(startup);

    const predictionData = PredictionEngine.predict(startup);

    const { data, error } = await supabase
      .from('predictions')
      .insert([predictionData])
      .select()
      .single();

    if (error) {
      console.error('Error saving prediction:', error);
    } else if (data) {
      setPrediction(data);
    }
  };

  const handleSubmitNew = async (startupData: Partial<Startup>) => {
    try {
      const { data, error } = await supabase
        .from('startups')
        .insert([startupData])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        await fetchStartups();
        handleAnalyzeStartup(data);
        setShowForm(false);
      }
    } catch (error) {
      console.error('Error creating startup:', error);
    }
  };

  const calculatePortfolioStats = () => {
    const totalInvestment = startups.reduce((sum, s) => sum + s.funding_amount, 0);
    const avgGrowth = startups.reduce((sum, s) => sum + s.growth_rate, 0) / (startups.length || 1);
    const highPotential = startups.filter(s => {
      const pred = PredictionEngine.predict(s);
      return pred.success_probability >= 70;
    }).length;

    return { totalInvestment, avgGrowth, highPotential };
  };

  const stats = calculatePortfolioStats();

  if (showForm) {
    return (
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => setShowForm(false)}
          className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Dashboard
        </button>
        <StartupForm onSubmit={handleSubmitNew} onCancel={() => setShowForm(false)} />
      </div>
    );
  }

  if (selectedStartup && prediction) {
    return (
      <div className="max-w-6xl mx-auto">
        <button
          onClick={() => {
            setSelectedStartup(null);
            setPrediction(null);
          }}
          className="mb-6 flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Portfolio
        </button>
        <PredictionResult prediction={prediction} startup={selectedStartup} />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Investment Portfolio</h1>
        <p className="text-gray-600">
          Evaluate startup opportunities and optimize your investment decisions
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Total Opportunities</h3>
            <Target className="w-5 h-5 text-blue-600" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{startups.length}</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Total Investment</h3>
            <DollarSign className="w-5 h-5 text-green-600" />
          </div>
          <p className="text-3xl font-bold text-gray-900">
            ${(stats.totalInvestment / 1000000).toFixed(1)}M
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-600">Avg Growth Rate</h3>
            <TrendingUp className="w-5 h-5 text-orange-600" />
          </div>
          <p className="text-3xl font-bold text-gray-900">{stats.avgGrowth.toFixed(1)}%</p>
        </div>
      </div>

      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold text-gray-900">Startup Opportunities</h2>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Evaluate New Startup
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-gray-300 border-t-blue-600"></div>
          <p className="mt-4 text-gray-600">Loading opportunities...</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {startups.map((startup) => (
            <StartupCard
              key={startup.id}
              startup={startup}
              onClick={() => handleAnalyzeStartup(startup)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
