import { Startup } from '../types';
import { Building2, Users, DollarSign, TrendingUp } from 'lucide-react';

interface StartupCardProps {
  startup: Startup;
  onClick?: () => void;
}

export function StartupCard({ startup, onClick }: StartupCardProps) {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer border border-gray-200"
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-1">{startup.name}</h3>
          <p className="text-sm text-gray-600">{startup.industry}</p>
        </div>
        <div className="bg-blue-50 rounded-full p-2">
          <Building2 className="w-6 h-6 text-blue-600" />
        </div>
      </div>

      <p className="text-sm text-gray-700 mb-4 line-clamp-2">{startup.description}</p>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-gray-500" />
          <span className="text-sm text-gray-700">{startup.team_size} team</span>
        </div>
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-gray-500" />
          <span className="text-sm text-gray-700">
            ${(startup.funding_amount / 1000000).toFixed(1)}M
          </span>
        </div>
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-gray-500" />
          <span className="text-sm text-gray-700">{startup.growth_rate}% growth</span>
        </div>
        <div className="text-sm text-gray-700">
          {startup.customer_count.toLocaleString()} customers
        </div>
      </div>

      <div className="pt-4 border-t border-gray-100">
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">Founded {startup.founding_year}</span>
          <span className="text-xs text-gray-500">{startup.location}</span>
        </div>
      </div>
    </div>
  );
}
