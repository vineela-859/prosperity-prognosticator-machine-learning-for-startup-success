import { Startup, Prediction } from '../types';

export class PredictionEngine {
  private static calculateFundingScore(startup: Startup): number {
    const fundingPerYear = startup.funding_amount / Math.max(1, new Date().getFullYear() - startup.founding_year);
    if (fundingPerYear > 5000000) return 100;
    if (fundingPerYear > 2000000) return 85;
    if (fundingPerYear > 1000000) return 70;
    if (fundingPerYear > 500000) return 55;
    return 40;
  }

  private static calculateTeamScore(startup: Startup): number {
    if (startup.team_size >= 50) return 95;
    if (startup.team_size >= 20) return 85;
    if (startup.team_size >= 10) return 70;
    if (startup.team_size >= 5) return 55;
    return 35;
  }

  private static calculateRevenueScore(startup: Startup): number {
    if (!startup.has_revenue) return 20;
    if (startup.revenue > 5000000) return 100;
    if (startup.revenue > 1000000) return 85;
    if (startup.revenue > 500000) return 70;
    if (startup.revenue > 100000) return 55;
    return 40;
  }

  private static calculateGrowthScore(startup: Startup): number {
    if (startup.growth_rate > 100) return 100;
    if (startup.growth_rate > 50) return 85;
    if (startup.growth_rate > 25) return 70;
    if (startup.growth_rate > 10) return 50;
    return 30;
  }

  private static calculateMarketScore(startup: Startup): number {
    if (startup.market_size > 10000000000) return 95;
    if (startup.market_size > 5000000000) return 80;
    if (startup.market_size > 1000000000) return 65;
    if (startup.market_size > 500000000) return 50;
    return 35;
  }

  private static calculateTractionScore(startup: Startup): number {
    const hasProduct = startup.has_product ? 30 : 0;
    const hasRevenue = startup.has_revenue ? 30 : 0;
    const customerScore = Math.min(40, (startup.customer_count / 1000) * 40);
    return hasProduct + hasRevenue + customerScore;
  }

  private static calculateRunwayScore(startup: Startup): number {
    if (startup.runway_months >= 24) return 95;
    if (startup.runway_months >= 18) return 85;
    if (startup.runway_months >= 12) return 70;
    if (startup.runway_months >= 6) return 45;
    return 20;
  }

  private static identifyStrengths(startup: Startup, scores: Record<string, number>): string[] {
    const strengths: string[] = [];

    if (scores.funding >= 80) strengths.push('Strong funding position');
    if (scores.team >= 80) strengths.push('Large and capable team');
    if (scores.revenue >= 80) strengths.push('Solid revenue generation');
    if (scores.growth >= 80) strengths.push('High growth trajectory');
    if (scores.market >= 80) strengths.push('Large addressable market');
    if (scores.traction >= 80) strengths.push('Strong market traction');
    if (scores.runway >= 80) strengths.push('Healthy financial runway');

    if (startup.funding_rounds >= 3) strengths.push('Multiple successful funding rounds');
    if (startup.customer_count > 500) strengths.push('Strong customer base');

    return strengths;
  }

  private static identifyRisks(startup: Startup, scores: Record<string, number>): string[] {
    const risks: string[] = [];

    if (scores.runway < 50) risks.push('Limited financial runway');
    if (scores.funding < 50) risks.push('Insufficient funding');
    if (!startup.has_revenue) risks.push('No revenue generation yet');
    if (scores.growth < 40) risks.push('Slow growth rate');
    if (startup.burn_rate > startup.revenue * 2) risks.push('High burn rate relative to revenue');
    if (startup.team_size < 5) risks.push('Small team size');
    if (startup.customer_count < 100) risks.push('Limited customer base');

    const yearsInBusiness = new Date().getFullYear() - startup.founding_year;
    if (yearsInBusiness > 3 && startup.revenue < 500000) risks.push('Slow revenue growth for stage');

    return risks;
  }

  private static calculateRiskLevel(successProbability: number): 'low' | 'medium' | 'high' {
    if (successProbability >= 70) return 'low';
    if (successProbability >= 45) return 'medium';
    return 'high';
  }

  private static generateRecommendation(successProbability: number, strengths: string[], risks: string[]): string {
    if (successProbability >= 75) {
      return 'Strong investment opportunity. The startup demonstrates excellent fundamentals across multiple dimensions with minimal risk factors.';
    } else if (successProbability >= 60) {
      return 'Promising investment opportunity. The startup shows solid potential with some notable strengths, though certain risk factors should be monitored.';
    } else if (successProbability >= 45) {
      return 'Moderate investment opportunity. The startup has potential but faces several challenges that need to be addressed for success.';
    } else {
      return 'High-risk investment. The startup faces significant challenges and would require substantial improvements to increase success probability.';
    }
  }

  public static predict(startup: Startup): Omit<Prediction, 'id' | 'predicted_at'> {
    const scores = {
      funding: this.calculateFundingScore(startup),
      team: this.calculateTeamScore(startup),
      revenue: this.calculateRevenueScore(startup),
      growth: this.calculateGrowthScore(startup),
      market: this.calculateMarketScore(startup),
      traction: this.calculateTractionScore(startup),
      runway: this.calculateRunwayScore(startup),
    };

    const weights = {
      funding: 0.15,
      team: 0.15,
      revenue: 0.20,
      growth: 0.20,
      market: 0.10,
      traction: 0.15,
      runway: 0.05,
    };

    const successProbability = Object.entries(scores).reduce(
      (total, [key, score]) => total + score * weights[key as keyof typeof weights],
      0
    );

    const strengths = this.identifyStrengths(startup, scores);
    const risks = this.identifyRisks(startup, scores);
    const riskLevel = this.calculateRiskLevel(successProbability);
    const recommendation = this.generateRecommendation(successProbability, strengths, risks);

    const confidenceScore = Math.min(
      95,
      60 + (strengths.length * 5) + (risks.length > 0 ? 0 : 10)
    );

    return {
      startup_id: startup.id,
      success_probability: Math.round(successProbability * 10) / 10,
      risk_level: riskLevel,
      key_strengths: strengths,
      key_risks: risks,
      recommendation,
      model_version: 'v1.0',
      confidence_score: Math.round(confidenceScore * 10) / 10,
      factors_analysis: scores,
    };
  }
}
