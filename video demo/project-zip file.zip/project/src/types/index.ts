export interface Startup {
  id: string;
  name: string;
  industry: string;
  founding_year: number;
  team_size: number;
  funding_amount: number;
  funding_rounds: number;
  revenue: number;
  growth_rate: number;
  market_size: number;
  has_product: boolean;
  has_revenue: boolean;
  customer_count: number;
  burn_rate: number;
  runway_months: number;
  location: string;
  description: string;
  created_at: string;
}

export interface Prediction {
  id: string;
  startup_id: string;
  success_probability: number;
  risk_level: 'low' | 'medium' | 'high';
  key_strengths: string[];
  key_risks: string[];
  recommendation: string;
  model_version: string;
  confidence_score: number;
  factors_analysis: Record<string, number>;
  predicted_at: string;
}

export interface Dataset {
  id: string;
  name: string;
  description: string;
  record_count: number;
  file_size: number;
  format: string;
  upload_date: string;
  processed: boolean;
  metadata: Record<string, unknown>;
}

export type UserType = 'investor' | 'entrepreneur' | 'policymaker';
