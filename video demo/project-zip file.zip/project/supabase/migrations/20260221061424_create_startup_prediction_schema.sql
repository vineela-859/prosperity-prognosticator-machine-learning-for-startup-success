/*
  # Startup Success Prediction Platform Schema

  ## Overview
  Database schema for machine learning-based startup success prediction platform supporting investors, entrepreneurs, and policy makers.

  ## New Tables

  ### `startups`
  Stores comprehensive startup information for analysis and prediction
  - `id` (uuid, primary key) - Unique startup identifier
  - `name` (text) - Startup name
  - `industry` (text) - Industry sector
  - `founding_year` (integer) - Year founded
  - `team_size` (integer) - Number of team members
  - `funding_amount` (numeric) - Total funding raised in USD
  - `funding_rounds` (integer) - Number of funding rounds
  - `revenue` (numeric) - Annual revenue in USD
  - `growth_rate` (numeric) - Year-over-year growth rate (percentage)
  - `market_size` (numeric) - Target market size in USD
  - `has_product` (boolean) - Has launched product
  - `has_revenue` (boolean) - Generates revenue
  - `customer_count` (integer) - Number of customers
  - `burn_rate` (numeric) - Monthly burn rate in USD
  - `runway_months` (integer) - Months of runway remaining
  - `location` (text) - Headquarters location
  - `description` (text) - Business description
  - `created_at` (timestamptz) - Record creation timestamp

  ### `predictions`
  Stores prediction results and success probability scores
  - `id` (uuid, primary key) - Unique prediction identifier
  - `startup_id` (uuid, foreign key) - Reference to startup
  - `success_probability` (numeric) - Predicted success probability (0-100)
  - `risk_level` (text) - Risk assessment (low, medium, high)
  - `key_strengths` (jsonb) - Array of identified strengths
  - `key_risks` (jsonb) - Array of identified risks
  - `recommendation` (text) - Investment/strategic recommendation
  - `model_version` (text) - ML model version used
  - `confidence_score` (numeric) - Prediction confidence level
  - `factors_analysis` (jsonb) - Detailed factor breakdown
  - `predicted_at` (timestamptz) - Prediction timestamp

  ### `datasets`
  Stores uploaded training datasets for model improvement
  - `id` (uuid, primary key) - Unique dataset identifier
  - `name` (text) - Dataset name
  - `description` (text) - Dataset description
  - `record_count` (integer) - Number of records
  - `file_size` (integer) - File size in bytes
  - `format` (text) - File format (csv, json)
  - `upload_date` (timestamptz) - Upload timestamp
  - `processed` (boolean) - Processing status
  - `metadata` (jsonb) - Additional metadata

  ## Security
  - Enable RLS on all tables
  - Public read access for demo purposes
  - Authenticated users can insert/update data
*/

-- Create startups table
CREATE TABLE IF NOT EXISTS startups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  industry text NOT NULL,
  founding_year integer NOT NULL,
  team_size integer DEFAULT 1,
  funding_amount numeric DEFAULT 0,
  funding_rounds integer DEFAULT 0,
  revenue numeric DEFAULT 0,
  growth_rate numeric DEFAULT 0,
  market_size numeric DEFAULT 0,
  has_product boolean DEFAULT false,
  has_revenue boolean DEFAULT false,
  customer_count integer DEFAULT 0,
  burn_rate numeric DEFAULT 0,
  runway_months integer DEFAULT 0,
  location text DEFAULT '',
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create predictions table
CREATE TABLE IF NOT EXISTS predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  startup_id uuid REFERENCES startups(id) ON DELETE CASCADE,
  success_probability numeric NOT NULL,
  risk_level text NOT NULL,
  key_strengths jsonb DEFAULT '[]'::jsonb,
  key_risks jsonb DEFAULT '[]'::jsonb,
  recommendation text DEFAULT '',
  model_version text DEFAULT 'v1.0',
  confidence_score numeric DEFAULT 0,
  factors_analysis jsonb DEFAULT '{}'::jsonb,
  predicted_at timestamptz DEFAULT now()
);

-- Create datasets table
CREATE TABLE IF NOT EXISTS datasets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  record_count integer DEFAULT 0,
  file_size integer DEFAULT 0,
  format text DEFAULT 'csv',
  upload_date timestamptz DEFAULT now(),
  processed boolean DEFAULT false,
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Enable RLS
ALTER TABLE startups ENABLE ROW LEVEL SECURITY;
ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE datasets ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access (demo purposes)
CREATE POLICY "Public read access for startups"
  ON startups FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public insert access for startups"
  ON startups FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Public update access for startups"
  ON startups FOR UPDATE
  TO public
  USING (true);

CREATE POLICY "Public read access for predictions"
  ON predictions FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public insert access for predictions"
  ON predictions FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Public read access for datasets"
  ON datasets FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public insert access for datasets"
  ON datasets FOR INSERT
  TO public
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_startups_industry ON startups(industry);
CREATE INDEX IF NOT EXISTS idx_startups_founding_year ON startups(founding_year);
CREATE INDEX IF NOT EXISTS idx_predictions_startup_id ON predictions(startup_id);
CREATE INDEX IF NOT EXISTS idx_predictions_success_probability ON predictions(success_probability);

-- Insert sample data
INSERT INTO startups (name, industry, founding_year, team_size, funding_amount, funding_rounds, revenue, growth_rate, market_size, has_product, has_revenue, customer_count, burn_rate, runway_months, location, description)
VALUES
  ('TechFlow AI', 'Artificial Intelligence', 2022, 15, 2500000, 2, 150000, 45, 5000000000, true, true, 250, 180000, 14, 'San Francisco, CA', 'AI-powered workflow automation platform'),
  ('GreenEnergy Solutions', 'Clean Technology', 2021, 28, 8500000, 3, 1200000, 120, 15000000000, true, true, 450, 450000, 18, 'Austin, TX', 'Renewable energy management systems'),
  ('HealthTrack', 'Healthcare Technology', 2023, 8, 500000, 1, 25000, 15, 3000000000, true, true, 80, 75000, 6, 'Boston, MA', 'Personal health monitoring and analytics'),
  ('FinSecure', 'Financial Technology', 2020, 45, 15000000, 4, 3500000, 80, 25000000000, true, true, 1200, 800000, 24, 'New York, NY', 'Blockchain-based security for financial transactions'),
  ('EduLearn Pro', 'Education Technology', 2022, 12, 1200000, 2, 80000, 30, 8000000000, true, true, 350, 120000, 10, 'Seattle, WA', 'Adaptive learning platform for K-12 education');
